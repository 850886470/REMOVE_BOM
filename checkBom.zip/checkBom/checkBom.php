<?php
header("Content-type: text/html; charset=utf-8");

$dir = "xxy";  //input your path
define('DELETE_BOM',false);  //Will delete bom if it is true.But be careful.


$files     = scandir($dir);

if(empty($files))
{
   exit('Dir not exists');
}

echo "<h2>Start to check bom , path ".__DIR__.substr($dir,0,1).'/'.$dir."</h2>";

iterator($dir,$files);

function iterator($dir,array $files ,$i = 0)
{
    if($i>6)
    {
        return false;
    }
    $left = str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;',$i);
    if(!empty($files) && is_array($files))
    {
        foreach ($files as $file)
        {

            if($file != '.' && $file != '..')
            {
                $path = $dir.'/'.$file;
                if(is_file($path))
                {
                    checkBom($path,$i);
                }
                else if(is_dir($path))
                {
                    $i++;
                    echo '<p>'.$left.$path.'</p>';
                    if(is_array(scandir($path)))
                    {
                        iterator($path,scandir($path),$i);
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
        }
    }
}




function checkBom($file,$i = 0)
{
    //Left length
    $left = str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;',$i);
    $a = file_get_contents($file);

    $b = urlencode($a);

    if(substr($b,0,9) == '%EF%BB%BF') {

        if(DELETE_BOM)
        {
            $b = substr($b, 9);
            $b = urldecode($b);
            file_put_contents($file,$b);
        }

        echo '<p style="color:red;">'.$left.$file.'  with bom</p>';
    }
    else
    {
        echo '<p style="color:green;">'.$left.$file.'  no bom</p>';
    }
}





?>
